#include "mcu_font.h"											    
#include "lcd.h"

uint16_t POINT_R;
uint16_t POINT_G;
uint16_t POINT_B;
uint16_t BACK_R;
uint16_t BACK_G;
uint16_t BACK_B;

//将utf-8编码转为unicode编码（函数来自LVGL）
static uint32_t lv_txt_utf8_next(const char * txt, uint32_t * i)
{
    /* Unicode to UTF-8
     * 00000000 00000000 00000000 0xxxxxxx -> 0xxxxxxx
     * 00000000 00000000 00000yyy yyxxxxxx -> 110yyyyy 10xxxxxx
     * 00000000 00000000 zzzzyyyy yyxxxxxx -> 1110zzzz 10yyyyyy 10xxxxxx
     * 00000000 000wwwzz zzzzyyyy yyxxxxxx -> 11110www 10zzzzzz 10yyyyyy 10xxxxxx
     * */

    uint32_t result = 0;
//printf("txt[%d]=%X %X %X\n",*i,txt[*i],txt[*i+1],txt[*i+2]);
    /*Dummy 'i' pointer is required*/
    uint32_t i_tmp = 0;
    if(i == NULL) i = &i_tmp;

    /*Normal ASCII*/
    if((txt[*i] & 0x80) == 0) {
        result = txt[*i];
        (*i)++;
    }
    /*Real UTF-8 decode*/
    else {
        /*2 bytes UTF-8 code*/
        if((txt[*i] & 0xE0) == 0xC0) {
            result = (uint32_t)(txt[*i] & 0x1F) << 6;
            (*i)++;
            if((txt[*i] & 0xC0) != 0x80) return 0; /*Invalid UTF-8 code*/
            result += (txt[*i] & 0x3F);
            (*i)++;
        }
        /*3 bytes UTF-8 code*/
        else if((txt[*i] & 0xF0) == 0xE0) {
            result = (uint32_t)(txt[*i] & 0x0F) << 12;
            (*i)++;

            if((txt[*i] & 0xC0) != 0x80) return 0; /*Invalid UTF-8 code*/
            result += (uint32_t)(txt[*i] & 0x3F) << 6;
            (*i)++;

            if((txt[*i] & 0xC0) != 0x80) return 0; /*Invalid UTF-8 code*/
            result += (txt[*i] & 0x3F);
            (*i)++;
        }
        /*4 bytes UTF-8 code*/
        else if((txt[*i] & 0xF8) == 0xF0) {
            result = (uint32_t)(txt[*i] & 0x07) << 18;
            (*i)++;

            if((txt[*i] & 0xC0) != 0x80) return 0; /*Invalid UTF-8 code*/
            result += (uint32_t)(txt[*i] & 0x3F) << 12;
            (*i)++;

            if((txt[*i] & 0xC0) != 0x80) return 0; /*Invalid UTF-8 code*/
            result += (uint32_t)(txt[*i] & 0x3F) << 6;
            (*i)++;

            if((txt[*i] & 0xC0) != 0x80) return 0; /*Invalid UTF-8 code*/
            result += txt[*i] & 0x3F;
            (*i)++;
        }
        else {
            (*i)++; /*Not UTF-8 char. Go the next.*/
        }
    }
    return result;
}

/** Searches base[0] to base[n - 1] for an item that matches *key.
 *
 * @note The function cmp must return negative if its first
 *  argument (the search key) is less that its second (a table entry),
 *  zero if equal, and positive if greater.
 *
 *  @note Items in the array must be in ascending order.
 *
 * @param key    Pointer to item being searched for
 * @param base   Pointer to first element to search
 * @param n      Number of elements
 * @param size   Size of each element
 * @param cmp    Pointer to comparison function (see #lv_font_codeCompare as a comparison function
 * example)
 *
 * @return a pointer to a matching item, or NULL if none exists.
 */
void * _lv_utils_bsearch(const void * key, const void * base, uint32_t n, uint32_t size,
                         int32_t (*cmp)(const void * pRef, const void * pElement))
{
    const char * middle;
    int32_t c;

    for(middle = base; n != 0;) {
        middle += (n / 2) * size;
        if((c = (*cmp)(key, middle)) > 0) {
            n    = (n / 2) - ((n & 1) == 0);
            base = (middle += size);
        }
        else if(c < 0) {
            n /= 2;
            middle = base;
        }
        else {
            return (char *)middle;
        }
    }
    return NULL;
}

/** Code Comparator.
 *
 *  Compares the value of both input arguments.
 *
 *  @param[in]  pRef        Pointer to the reference.
 *  @param[in]  pElement    Pointer to the element to compare.
 *
 *  @return Result of comparison.
 *  @retval < 0   Reference is greater than element.
 *  @retval = 0   Reference is equal to element.
 *  @retval > 0   Reference is less than element.
 *
 */
static int32_t unicode_list_compare(const void * ref, const void * element)
{
    return ((int32_t)(*(uint16_t *)ref)) - ((int32_t)(*(uint16_t *)element));
}

static uint32_t get_glyph_dsc_id(const lv_font_t * font, uint32_t letter)
{
	if(letter == '\0') return 0;

    lv_font_fmt_txt_dsc_t * fdsc = (lv_font_fmt_txt_dsc_t *) font->dsc;

    /*Check the cache first*/
    if(letter == fdsc->last_letter) return fdsc->last_glyph_id;

	uint32_t glyph_id = 0;
	if(fdsc->cmap_num == 1) 
	{

        /*Relative code point*/
        uint32_t rcp = letter - fdsc->cmaps[0].range_start;
        if(rcp > fdsc->cmaps[0].range_length) 
		{
			fdsc->last_letter = letter;
			fdsc->last_glyph_id = 0;
			return 0;
		}
        if(fdsc->cmaps[0].type == LV_FONT_FMT_TXT_CMAP_SPARSE_TINY) {
            uint8_t * p = _lv_utils_bsearch(&rcp, fdsc->cmaps[0].unicode_list, fdsc->cmaps[0].list_length,
                                            sizeof(fdsc->cmaps[0].unicode_list[0]), unicode_list_compare);

            if(p) {
                lv_uintptr_t ofs = (lv_uintptr_t)(p - (uint8_t *) fdsc->cmaps[0].unicode_list);
                ofs = ofs >> 1;     /*The list stores `uint16_t` so the get the index divide by 2*/
                glyph_id = fdsc->cmaps[0].glyph_id_start + ofs;
            }
        }
	}
	
	/*Update the cache*/
	fdsc->last_letter = letter;
	fdsc->last_glyph_id = glyph_id;
	return glyph_id;
}

/***********************************************************************************
 * 顶部到字模数据的距离 = line_height - box_h - baseline - ofs_y
 * 左侧到字模数据的距离 = ofs_x
 * 左侧到下一个字左侧的距离 = 实际字符宽度 = (adv_w + 8)/16
 * 
 * 字体颜色 = 字模数据 * (前景色 - 背景色)/(0xff>>(8-bpp)) + 背景色 
 *
 * ********************************************************************************/
void Show_MCU_Font(u16* x,u16* y,uint32_t unicode,const lv_font_t* font)
{
	if(unicode == '\t') unicode = ' ';

	uint16_t x0 = *x;
	uint16_t y0 = *y;

	lv_font_fmt_txt_dsc_t * fdsc = (lv_font_fmt_txt_dsc_t *) font->dsc;
	uint32_t gid = get_glyph_dsc_id(font,unicode);
	if(!gid) return;
	const lv_font_fmt_txt_glyph_dsc_t * gdsc = &fdsc->glyph_dsc[gid];

	uint32_t gsize = gdsc->box_w * gdsc->box_h;
	if(gsize == 0) return;

	

	int16_t g_ofs_y = font->line_height - gdsc->box_h - font->base_line - gdsc->ofs_y;
	int16_t g_ofs_x = gdsc->ofs_x;

	const uint8_t* bitmap = fdsc->glyph_bitmap;
	uint16_t index = gdsc->bitmap_index;
	uint8_t temp  = bitmap[index];
	uint8_t pix;
	uint8_t pixcount = 0;
	uint8_t pixperbyte = 8/fdsc->bpp;
    uint16_t colorR,colorG,colorB;
    
    extern _lcd_dev lcddev;
     if((x0 + ((gdsc->adv_w + 8)>>4)) > lcddev.width)//换行
    {	    
        *y+=font->line_height;
        y0=*y;
        *x=0;
        x0=*x;
    }
    
	for(*y=y0; *y < (y0 + font->line_height); (*y)++)
	{
		for(*x=x0; *x < (x0 + ((gdsc->adv_w + 8)>>4)); (*x)++)
		{            
			if(*y>=(y0+g_ofs_y) && *y<(y0 + g_ofs_y+gdsc->box_h) && *x>=(x0 + g_ofs_x) && *x<(x0 + g_ofs_x + gdsc->box_w))
			{				
				pix = temp >> (8-fdsc->bpp);
                
                colorR = pix*(POINT_R-BACK_R)/(0xff>>(8-fdsc->bpp)) + BACK_R;
                colorG = pix*(POINT_G-BACK_G)/(0xff>>(8-fdsc->bpp)) + BACK_G;
                colorB = pix*(POINT_B-BACK_B)/(0xff>>(8-fdsc->bpp)) + BACK_B;
                LCD_Fast_DrawPoint(*x,*y,(colorR & RED) + (colorG & GREEN) + (colorB & BLUE));

				temp = temp<<fdsc->bpp;
				pixcount++;
				if(pixcount >= pixperbyte)
				{
					temp = bitmap[++index];
					pixcount = 0;
				}
			}else
			{
				LCD_Fast_DrawPoint(*x,*y,BACK_COLOR); 
			}
			
		}
	}
    
    *y = y0;

}



void Show_MCU_Str(u16 x,u16 y,u16 width,u16 height,const char* txt,const lv_font_t* font)
{
	uint32_t i = 0;	
	uint32_t unicode;
    POINT_R = POINT_COLOR & RED;
    POINT_G = POINT_COLOR & GREEN;
    POINT_B = POINT_COLOR & BLUE;
    BACK_R = BACK_COLOR & RED;
    BACK_G = BACK_COLOR & GREEN;
    BACK_B = BACK_COLOR & BLUE;
    
	do{
		unicode = lv_txt_utf8_next(txt,&i);		
               
		Show_MCU_Font(&x,&y,unicode,font);
        
	}while(unicode);
}  

























		  






