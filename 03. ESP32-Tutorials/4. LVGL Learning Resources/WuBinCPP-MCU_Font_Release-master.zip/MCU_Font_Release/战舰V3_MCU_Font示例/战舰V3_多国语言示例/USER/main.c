#include "sys.h"
#include "delay.h"
#include "led.h" 		 	 
#include "lcd.h"  
#include "key.h"     
#include "mcu_font.h"
 
/************************************************
 ALIENTEK战舰STM32开发板实验40
 汉字显示 实验 
 技术支持：www.openedv.com
 淘宝店铺：http://eboard.taobao.com 
 关注微信公众平台微信号："正点原子"，免费获取STM32资料。
 广州市星翼电子科技有限公司  
 作者：正点原子 @ALIENTEK
************************************************/

extern const lv_font_t mcu_font_20;
extern const lv_font_t mcu_font_30;
extern const lv_font_t mcu_font_40;
 int main(void)
 {	 
	delay_init();	    	 //延时函数初始化	  
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);//设置中断优先级分组为组2：2位抢占优先级，2位响应优先级	
 	LED_Init();		  			//初始化与LED连接的硬件接口
	KEY_Init();					//初始化按键
	LCD_Init();			   		//初始化LCD   	

	POINT_COLOR=RED; 
    Show_MCU_Str(0,50,300,100,"你好-안녕하십니까-こんにちは---",&mcu_font_20);
 	
    POINT_COLOR=BLUE;
    Show_MCU_Str(0,150,300,100,"你好-안녕하십니까-こんにちは---",&mcu_font_30);

    POINT_COLOR=GREEN;
    Show_MCU_Str(0,250,300,100,"你好-안녕하십니까-こんにちは---",&mcu_font_40);
    
	while(1)
	{
        
	} 
}

















