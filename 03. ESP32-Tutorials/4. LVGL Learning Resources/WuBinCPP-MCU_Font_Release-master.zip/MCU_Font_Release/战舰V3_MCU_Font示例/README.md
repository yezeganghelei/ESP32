模板例程：正点原子战舰V3开发板  实验40 汉字显示实验

修改内容：

### 1、增加字模解析代码

​	mcu_font.c  mcu_font.h  lvgh.h  (lvgl官方代码修改而来)

### 2、多开3个 MCU_Font 软件用于提取及生成3种大小的字体文件

![1600524440969](https://gitee.com/WuBinCPP/MCU_Font_Release/raw/master/image/1600524440969.png)

### 3、主程序main编码改UTF-8，并调用显示函数 Show_MCU_Str() 显示多国语言 

```c
...
#include "mcu_font.h"
extern const lv_font_t mcu_font_20;
extern const lv_font_t mcu_font_30;
extern const lv_font_t mcu_font_40;
int main(void)
{	 
	delay_init();
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
    LED_Init();		  		
    KEY_Init();
    LCD_Init();	

    POINT_COLOR=RED; 
    Show_MCU_Str(0,50,300,100,"你好-안녕하십니까-こんにちは---",&mcu_font_20);
 	
    POINT_COLOR=BLUE;
    Show_MCU_Str(0,150,300,100,"你好-안녕하십니까-こんにちは---",&mcu_font_30);

    POINT_COLOR=GREEN;
    Show_MCU_Str(0,250,300,100,"你好-안녕하십니까-こんにちは---",&mcu_font_40);
    
	while(1)
	{
        
	} 
}
```

### 4、显示效果

![1600525172146](https://gitee.com/WuBinCPP/MCU_Font_Release/raw/master/image/1600525172146.png)